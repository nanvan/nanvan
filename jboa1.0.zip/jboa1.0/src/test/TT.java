package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import cn.edu.hzvtc.action.EmployeeAction;
import cn.edu.hzvtc.entity.Department;
import cn.edu.hzvtc.entity.Employee;
import cn.edu.hzvtc.entity.Position;
import cn.edu.hzvtc.exception.JboaException;
import cn.edu.hzvtc.service.EmployeeService;

public class TT {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws JboaException {
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"applicationContext.xml");

		EmployeeAction empAction = (EmployeeAction) ctx
				.getBean("employeeAction");
		EmployeeService employeeService = (EmployeeService) ctx.getBean("employeeService");
		Employee emp = employeeService.getEmployeeBySN("001");
		System.out.println(emp);
		Employee employee = new Employee();
		Department dept = new Department();
		Position pos = new Position();
		
		/*添加*/
		/*employee.setSn("111");
		employee.setName("aaa");
		employee.setPassword("123");
		dept.setId(1);
		pos.setId(1);
		employee.setDepartment(dept);
		employee.setPosition(pos);
		employee.setStatus("在职");
		
		employeeService.saveEmployee(employee);*/
		
		/*删除*/
		employeeService.delete("111");
		
		/*修改*/
		/*employee.setSn("111");
		employee.setName("aaa");
		employee.setPassword("123");
		dept.setId(1);
		pos.setId(1);
		employee.setDepartment(dept);
		employee.setPosition(pos);
		employee.setStatus("离职");
		employeeService.update(employee);*/
		
		
		//empAction.login();
}
	}
