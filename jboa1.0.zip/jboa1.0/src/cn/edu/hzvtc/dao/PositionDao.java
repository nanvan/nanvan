package cn.edu.hzvtc.dao;

import cn.edu.hzvtc.entity.Position;

public interface PositionDao extends BaseDao<Position> {

}
