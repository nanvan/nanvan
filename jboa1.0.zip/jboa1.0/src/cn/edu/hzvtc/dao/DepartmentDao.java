package cn.edu.hzvtc.dao;

import cn.edu.hzvtc.entity.Department;

public interface DepartmentDao extends BaseDao<Department> {

}
