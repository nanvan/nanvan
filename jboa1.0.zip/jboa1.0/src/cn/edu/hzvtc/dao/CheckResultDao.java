package cn.edu.hzvtc.dao;

import cn.edu.hzvtc.entity.CheckResult;

public interface CheckResultDao extends BaseDao<CheckResult> {

}
