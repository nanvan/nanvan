package cn.edu.hzvtc.dao;

import cn.edu.hzvtc.entity.ClaimVoucherDetail;

public interface ClaimVoucherDetailDao extends BaseDao<ClaimVoucherDetail>{

	public void deleteClaimVoucherById(Long id);



}
