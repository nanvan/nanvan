package cn.edu.hzvtc.dao.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import cn.edu.hzvtc.dao.ClaimVoucherStatisticsDao;
import cn.edu.hzvtc.dao.DepartmentDao;
import cn.edu.hzvtc.entity.ClaimVoucherStatistics;
import cn.edu.hzvtc.entity.Department;
import cn.edu.hzvtc.util.DateUtil;
import cn.edu.hzvtc.util.PaginationUtil;

public class ClaimVoucherStatisticsDaoImpl extends
BaseDaoImpl<ClaimVoucherStatistics> implements
ClaimVoucherStatisticsDao {
	private DepartmentDao departmentDao;

	public DepartmentDao getDepartmentDao() {
		return departmentDao;
	}

	public void setDepartmentDao(DepartmentDao departmentDao) {
		this.departmentDao = departmentDao;
	}

	public void saveBySchedulerSearch() {
		// 查询
		System.out.println("开始执行入库");
		try {
			// 得到上个月的起止吋间
			Date firstDayOfLastMonth = DateUtil.getFirstDayOfLastMonth();
			Date lastDayOfLastMonth = DateUtil.getLastDayOfLastMonth();
			String hql = " SELECT SUM(bcv.totalAccount),bcv.creator.department.id" + " FROM ClaimVoucher bcv"
					+ " WHERE bcv.modifyTime <= '" + DateUtil.dateToStr(lastDayOfLastMonth, "yyyy-MM-dd hh:mm:ss")
					+ "' AND bcv.modifyTime >= '" + DateUtil.dateToStr(firstDayOfLastMonth, "yyyy-MM-dd hh:mm:ss")
					+ "' AND bcv .status = '已付款'" + " GROUP BY bcv.creator.department.name";
			List<Object[]> list = this.getSession().createQuery(hql).list();

			// 入库F
			int year = DateUtil.getYear(firstDayOfLastMonth);
			int month = DateUtil.getMonth(firstDayOfLastMonth);
			Iterator<Object[]> it = list.iterator();
			while (it.hasNext()) {
				ClaimVoucherStatistics result = new ClaimVoucherStatistics();
				Object[] o = (Object[]) it.next();
				result.setTotalCount((Double) o[0]);
				Department dept = departmentDao.findById((Integer) o[1]);
				// Integer
				result.setDepartment(dept);
				result.setYear(year);
				result.setMonth(month);
				result.setModifyTime(new Date());
				this.save(result);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("入库完毕");
	}
	
	@Override
	public PaginationUtil<ClaimVoucherStatistics> getDeptClaimVoucherStatisticByPage(int year, int startMonth,
			int endMonth, int departmentId, int pageNo, int pageSize) {
		// TODO Auto-generated method stub
		String hql = "FROM ClaimVoucherStatistics cvs ";
		String strCondition = "";
		if (year != 0) {// 是员工
			// add添加查询条件
			strCondition = strCondition + " cvs.year=" + year;
		}
		if (startMonth != 0) {
			if (!strCondition.equals("")) {
				strCondition = strCondition + " AND ";
			}
			strCondition = strCondition = " cvs.month>=" + startMonth;
		}
		if (endMonth != 0) {
			if (!strCondition.equals("")) {
				strCondition = strCondition + " AND ";
			}
			strCondition = strCondition = " cvs.month<=" + endMonth;
		}
		if (departmentId != 0) {
			if (!strCondition.equals("")) {
				strCondition = strCondition + " AND ";
			}
			strCondition = strCondition + " cvs.department.id=" + departmentId;
		}
		if (!strCondition.equals("")) {
			hql = hql + " WHERE " + strCondition;
		}
		hql = hql + " ORDER BY cvs.month DESC";

		return this.queryPage(hql, pageNo, pageSize);
	}
	@Override
	public List<ClaimVoucherStatistics> getCompClaimVoucherByMonth(int year, int startMonth, int endMonth) {
		// TODO Auto-generated method stub
		List<ClaimVoucherStatistics> result = new ArrayList<ClaimVoucherStatistics>();
		if(endMonth == 0) {
			endMonth = 12;
		}
		String hql = " SELECT SUM(cvs.totalCount), cvs.year, cvs.month "
				+ " FROM ClaimVoucherStatistics cvs" + " WHERE cvs.month >= "
				+ startMonth + " AND cvs.month <= " + endMonth;
		if(year > 0) {
			hql = hql + " AND cvs.year = " + year;
		}
		hql = hql + " GROUP BY cvs.year, cvs.month "
				+ " ORDER BY cvs.year DESC, cvs.month DESC";
		List<Object[]> list = this.getSession().createQuery(hql).list();
		for(Object[] o : list) {
			ClaimVoucherStatistics cvs = new ClaimVoucherStatistics();
			cvs.setTotalCount((Double) o[0]);
			cvs.setYear((Integer) o[1]);
			cvs.setMonth((Integer) o[2]);
			result.add(cvs);
		}
		return result;
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<ClaimVoucherStatistics> getClaimVoucherStatisticsByDateAndDept(int year, int month) {
		// TODO Auto-generated method stub
		try {
			String hql = "FROM ClaimVoucherStatistics cvs WHERE cvs.year=" + year;
			if (month > 0) {
				hql = hql + " AND cvs.month=" + month;
			}
			hql = hql + " ORDER BY cvs.department.id";
			
			return this.getSession().createQuery(hql).list();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return null;
		}
	}
}
