package cn.edu.hzvtc.dao.impl;

import cn.edu.hzvtc.dao.PositionDao;
import cn.edu.hzvtc.entity.Position;

public class PositionDaoImpl extends BaseDaoImpl<Position> implements
		PositionDao {

}
