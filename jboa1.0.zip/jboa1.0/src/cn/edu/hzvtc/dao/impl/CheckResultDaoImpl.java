package cn.edu.hzvtc.dao.impl;

import cn.edu.hzvtc.dao.CheckResultDao;
import cn.edu.hzvtc.entity.CheckResult;

public class CheckResultDaoImpl extends BaseDaoImpl<CheckResult> implements
		CheckResultDao {

}
