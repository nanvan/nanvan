package cn.edu.hzvtc.dao.impl;

import cn.edu.hzvtc.dao.DepartmentDao;
import cn.edu.hzvtc.entity.Department;

public class DepartmentDaoImpl extends BaseDaoImpl<Department> implements
		DepartmentDao {

}
