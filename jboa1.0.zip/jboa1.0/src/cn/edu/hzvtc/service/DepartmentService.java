package cn.edu.hzvtc.service;

import java.util.List;

import cn.edu.hzvtc.entity.Department;

public interface DepartmentService {

	List<Department> getAll();

}
