package cn.edu.hzvtc.service;

public interface ClaimVoucherDetailService {

}
