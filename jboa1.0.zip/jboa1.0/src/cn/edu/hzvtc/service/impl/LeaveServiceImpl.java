package cn.edu.hzvtc.service.impl;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import cn.edu.hzvtc.dao.LeaveDao;
import cn.edu.hzvtc.entity.Leave;
import cn.edu.hzvtc.service.LeaveService;
import cn.edu.hzvtc.util.ConstantUtil;
import cn.edu.hzvtc.util.PaginationUtil;

public class LeaveServiceImpl implements LeaveService {
	private LeaveDao leaveDao;

	public LeaveDao getLeaveDao() {
		return leaveDao;
	}

	public void setLeaveDao(LeaveDao leaveDao) {
		this.leaveDao = leaveDao;
	}

	@Override 
	public PaginationUtil<Leave> getLeavePage(String createSn, String dealSn,
			String startDate, String endDate, int pageNo, int pageSize) {
		return leaveDao.getLeavePage(createSn,dealSn,startDate, endDate, pageNo, pageSize);
	}

	@Override
	public Leave findLeaveById(Long id) {
		// TODO Auto-generated method stub
		return (Leave)leaveDao.findById(id);
	}

	@Override
	public boolean checkLeave(Leave leave) {
		// TODO Auto-generated method stub
		boolean bRet = false;
		try {
			Leave oldLeave = leaveDao.findById(leave.getId());
			oldLeave.setStatus(leave.getStatus());
			oldLeave.setApproveOpinion(leave.getApproveOpinion());
			oldLeave.setModifyTime(new Date());
			leaveDao.update(oldLeave);
			bRet = true;
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return bRet;
	}

	@Override
	public boolean saveLeave(Leave leave) {
		// TODO Auto-generated method stub
		boolean bRet = false;
		try {
			leave.setStatus(ConstantUtil.LEAVESTATUS_APPROVING);
			leave.setCreateTime(new Date());
			leaveDao.save(leave);
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return bRet;
	}

	@Override
	public Map<String, String> getLeaveTypeMap() {
		// TODO Auto-generated method stub
		Map<String, String> leaveMap = new LinkedHashMap<String, String>();
		leaveMap.put(ConstantUtil.LEAVE_ANNUAL, ConstantUtil.LEAVE_ANNUAL);
		leaveMap.put(ConstantUtil.LEAVE_CASUAL, ConstantUtil.LEAVE_CASUAL);
		leaveMap.put(ConstantUtil.LEAVE_MARRIAGE, ConstantUtil.LEAVE_MARRIAGE);
		leaveMap.put(ConstantUtil.LEAVE_MATERNITY, ConstantUtil.LEAVE_MATERNITY);
		leaveMap.put(ConstantUtil.LEAVE_SICK, ConstantUtil.LEAVE_SICK);
		return leaveMap;
	}
	}
