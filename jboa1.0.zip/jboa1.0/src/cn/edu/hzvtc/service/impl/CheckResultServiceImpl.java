package cn.edu.hzvtc.service.impl;

import java.util.Date;

import cn.edu.hzvtc.dao.CheckResultDao;
import cn.edu.hzvtc.dao.ClaimVoucherDao;
import cn.edu.hzvtc.dao.EmployeeDao;
import cn.edu.hzvtc.entity.CheckResult;
import cn.edu.hzvtc.entity.ClaimVoucher;
import cn.edu.hzvtc.entity.Employee;
import cn.edu.hzvtc.service.CheckResultService;
import cn.edu.hzvtc.util.ConstantUtil;

public class CheckResultServiceImpl implements CheckResultService {
	private ClaimVoucherDao claimVoucherDao;
	private CheckResultDao checkResultDao;
	private EmployeeDao employeeDao;
	
	public ClaimVoucherDao getClaimVoucherDao() {
		return claimVoucherDao;
	}
	public void setClaimVoucherDao(ClaimVoucherDao claimVoucherDao) {
		this.claimVoucherDao = claimVoucherDao;
	}
	public CheckResultDao getCheckResultDao() {
		return checkResultDao;
	}
	public void setCheckResultDao(CheckResultDao checkResultDao) {
		this.checkResultDao = checkResultDao;
	}
	public EmployeeDao getEmployeeDao() {
		return employeeDao;
	}
	public void setEmployeeDao(EmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}
	
	@Override
	public boolean saveCheckResult(CheckResult checkResult) {
		boolean bRet = false;
	try {
		Long claimId = checkResult.getClaimVoucher().getId();
		ClaimVoucher claimVoucher =(ClaimVoucher) claimVoucherDao.findClaimVoucherById(claimId);
		Employee empCheck = checkResult.getCheckEmployee();
		claimVoucher = updateClaimVoucherStatus(empCheck.getPosition().getNameCn(), checkResult.getResult(), claimVoucher);
		claimVoucher.setModifyTime(new Date(System.currentTimeMillis()));
		claimVoucherDao.update(claimVoucher);
		checkResult.setCheckTime(new Date(System.currentTimeMillis()));
		checkResultDao.save(checkResult);
		
		bRet = true;
	}catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	return bRet;
	}
	
	private ClaimVoucher updateClaimVoucherStatus(String position, 
			String checkResult, ClaimVoucher claimVoucher) {
		// TODO Auto-generated method stub
		if (checkResult.equals(ConstantUtil.CHECKRESULT_PASS)) {
			if (position.equals(ConstantUtil.POSITION_FM)) {
				if (claimVoucher.getTotalAccount() >= 5000) {
					claimVoucher.setStatus(ConstantUtil.CLAIMVOUCHER_APPROVING);
					claimVoucher.setNextDeal(employeeDao.getGeneralManager());
				} else {
					claimVoucher.setStatus(ConstantUtil.CLAIMVOUCHER_APPROVED);
					claimVoucher.setNextDeal(employeeDao.getCashier());
				}
			} else if (position.equals(ConstantUtil.POSITION_GM)) {
					claimVoucher.setStatus(ConstantUtil.CLAIMVOUCHER_APPROVED);
					claimVoucher.setNextDeal(employeeDao.getCashier());
			} else {
				claimVoucher.setStatus(ConstantUtil.CLAIMVOUCHER_PAID);
				claimVoucher.setNextDeal(null);
			}
		} else if (checkResult.equals(ConstantUtil.CHECKRESULT_REJECT)) {
			claimVoucher.setStatus(ConstantUtil.CLAIMVOUCHER_TERMINATED);
			claimVoucher.setNextDeal(null);
		} else if (checkResult.equals(ConstantUtil.CHECKRESULT_BACK)) {
			claimVoucher.setStatus(ConstantUtil.CLAIMVOUCHER_BACK);
			claimVoucher.setNextDeal(claimVoucher.getCreator());
		}
		return claimVoucher;
	}

}
