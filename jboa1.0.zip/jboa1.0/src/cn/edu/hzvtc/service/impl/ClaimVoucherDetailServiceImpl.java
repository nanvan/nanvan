package cn.edu.hzvtc.service.impl;

import cn.edu.hzvtc.service.ClaimVoucherDetailService;

public class ClaimVoucherDetailServiceImpl implements ClaimVoucherDetailService {

}
