package cn.edu.hzvtc.service.impl;

import cn.edu.hzvtc.service.PositionService;

public class PositionServiceImpl implements PositionService {

}
