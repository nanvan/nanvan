package cn.edu.hzvtc.service;

public interface PositionService {

}
