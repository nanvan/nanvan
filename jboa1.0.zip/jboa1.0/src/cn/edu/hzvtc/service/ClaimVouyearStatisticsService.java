package cn.edu.hzvtc.service;

import java.util.List;

import cn.edu.hzvtc.entity.ClaimVouyearStatistics;
import cn.edu.hzvtc.util.PaginationUtil;

public interface ClaimVouyearStatisticsService {

	public void saveVoucherStatisticsByYear();

	PaginationUtil<ClaimVouyearStatistics> getDeptClaimVoucherStatisticsByPage(int startYear, int endYear,
			int departmentId, int pageNo, int pageSize);

	List<ClaimVouyearStatistics> getCompClaimVoucherStatisticsByPage(int startYear, int endYear);

	List<ClaimVouyearStatistics> getCompClaimVoucherStatisticsByYear(int year);
}
