package cn.edu.hzvtc.service;

import cn.edu.hzvtc.entity.CheckResult;

public interface CheckResultService {

	public boolean saveCheckResult(CheckResult checkResult);

}
