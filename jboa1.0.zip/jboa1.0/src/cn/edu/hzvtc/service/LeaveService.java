package cn.edu.hzvtc.service;

import java.util.Map;

import cn.edu.hzvtc.entity.Leave;
import cn.edu.hzvtc.util.PaginationUtil;

public interface LeaveService {

	PaginationUtil<Leave> getLeavePage(String createSn, String dealSn, String startDate, String endDate, int pageNo,
			int pageSize);

	Leave findLeaveById(Long id);

	boolean checkLeave(Leave leave);

	boolean saveLeave(Leave leave);

	Map<String, String> getLeaveTypeMap();

}
