package cn.edu.hzvtc.exception;

public class JboaException extends Exception {

	private static final long serialVersionUID = 1L;

}
