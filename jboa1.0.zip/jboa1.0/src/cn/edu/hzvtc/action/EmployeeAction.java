package cn.edu.hzvtc.action;

import cn.edu.hzvtc.entity.Employee;
import cn.edu.hzvtc.exception.JboaException;
import cn.edu.hzvtc.service.EmployeeService;
import cn.edu.hzvtc.util.ConstantUtil;

public class EmployeeAction extends BaseAction {
	private static final long serialVersionUID = 1L;
	private EmployeeService employeeService; // 用户业务类
	private Employee employee;
	private String validationCode;
	private Employee manager;
	

	public void setEmployeeService(EmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public String getValidationCode() {
		return validationCode;
	}

	public void setValidationCode(String validationCode) {
		this.validationCode = validationCode;
	}

	public Employee getManager() {
		return manager;
	}

	public void setManager(Employee manager) {
		this.manager = manager;
	}

	public String login() {
		try {
			String code =  (String) this.getSession().get("valiclationCode");
			if(code.equals(validationCode )) {
				employee = employeeService.login(employee);
				manager = employeeService.getManager(employee);
				//存放 employee
				this.getSession(). put(ConstantUtil.AUTH_EMPLOYEE, employee);
				this.getSession(). put(ConstantUtil.AUTH_EMPLOYEE_MANAGER,manager);
				this.getSession(). put(ConstantUtil.EMPLOYEE_POSITION,
						employee.getPosition(). getNameCn());
			}else {
				addActionError(getText("错误:验证码输入有误!"));
			}
		}catch (JboaException ex) {
			addActionError(getText("错误:用户名或密码输入有误!"));
		}
		if (hasActionErrors()) {
				return INPUT;
		}

		// 登录
		return SUCCESS;
	}
	public String logout() {
		this.getSession(). put(ConstantUtil.AUTH_EMPLOYEE, null);
		this.getSession(). put(ConstantUtil.AUTH_EMPLOYEE_MANAGER,null);
		this.getSession(). put(ConstantUtil.EMPLOYEE_POSITION,null);
		return "logoutSuccess";
	}
}
