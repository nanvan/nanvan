package cn.edu.hzvtc.action;

import cn.edu.hzvtc.entity.CheckResult;
import cn.edu.hzvtc.service.CheckResultService;

public class CheckResultAction extends BaseAction {
	private static final long serialVersionUID = 1L;
	
	private CheckResultService checkResultService;
	private CheckResult checkResult;
	public CheckResultService getCheckResultService() {
		return checkResultService;
	}
	public void setCheckResultService(CheckResultService checkResultService) {
		this.checkResultService = checkResultService;
	}
	public CheckResult getCheckResult() {
		return checkResult;
	}
	public void setCheckResult(CheckResult checkResult) {
		this.checkResult = checkResult;
	}
	
	public String checkClaimVoucher() {
		checkResult.setCheckEmployee(getLoginEmployee());
		boolean bRet = checkResultService.saveCheckResult(checkResult);
		if(bRet) {
			return SUCCESS;
		} else {
			return INPUT;
		}
		
	}
}
