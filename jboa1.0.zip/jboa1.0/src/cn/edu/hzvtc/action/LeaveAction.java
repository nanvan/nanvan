package cn.edu.hzvtc.action;

import java.util.List;
import java.util.Map;

import cn.edu.hzvtc.entity.Department;
import cn.edu.hzvtc.entity.Employee;
import cn.edu.hzvtc.entity.Leave;
import cn.edu.hzvtc.service.DepartmentService;
import cn.edu.hzvtc.service.LeaveService;

public class LeaveAction extends BaseAction {
	private static final long serialVersionUID = 1L;
	private LeaveService leaveService;
	private DepartmentService departmentService;
	private Leave leave;
	private String startDate;
	private String endDate;
	
	private Employee nextDeal;
	
	public String searchLeave() {
		//查询请假单
		String createSn = "";
		String dealSn = "";
		if (isStaff()){
			createSn = getCurrentSn();
		} else {
			dealSn = getCurrentSn();
		}
		pageUtil = leaveService.getLeavePage(createSn, dealSn, startDate, endDate, pageNo, pageSize);
		return "list";
	}
	
	public String toEdit() {
		return "edit";
	}
	
	public String toCheck() {
		leave = leaveService.findLeaveById(leave.getId());
		return "check";
	}
	
	public String checkLeave() {
		leaveService.checkLeave(leave);
		return "redirectList";
	}
	
	public String saveLeave(){
		Employee employee = (Employee) getSession().get("manager");
		leave.setNextDeal(employee);
		leaveService.saveLeave(leave);
		return "redirectList";
	}

	public void setLeaveService(LeaveService leaveService) {
		this.leaveService = leaveService;
	}

	public void setDepartmentService(DepartmentService departmentService) {
		this.departmentService = departmentService;
	}

	public Leave getLeave() {
		return leave;
	}

	public void setLeave(Leave leave) {
		this.leave = leave;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	public Map<String, String> getLeaveTypeMap() {
		return leaveService.getLeaveTypeMap();
	}
	
	public String getLeaveById() {
		leave = leaveService.findLeaveById(leave.getId());
		return "view";
	}
	

	public List<Department> getDepartmentList() {
		return departmentService.getAll();
	}

	public Employee getNextDeal() {
		return nextDeal;
	}

	public void setNextDeal(Employee nextDeal) {
		this.nextDeal = nextDeal;
	}
	
}
