package cn.edu.hzvtc.action;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import cn.edu.hzvtc.entity.ClaimVoucherStatistics;
import cn.edu.hzvtc.service.ClaimVoucherStatisticsService;
import cn.edu.hzvtc.util.ExportExcelUtil;
import cn.edu.hzvtc.util.JFreeChatUtil;

public class CompMonthStatisticsAction extends BaseAction {
	private static final long serialVersionUID = 1L;
	
	private ClaimVoucherStatisticsService claimVoucherStatisticsService;
	
	private int year;
	private int startMonth;
	private int endMonth;
	private int currMonth;
	private String totalCount;
	private JFreeChart chart;
	private List<ClaimVoucherStatistics> statisticsListOfCompMonth;
	private List<ClaimVoucherStatistics> statisticsDetailOfCompMonth;
	
	public String getList() {
		statisticsListOfCompMonth = claimVoucherStatisticsService
				.getCompClaimVoucherStatisticsByMonth(year, startMonth, endMonth);
		return "list";
	}
	public String getDetail() {
		statisticsDetailOfCompMonth = claimVoucherStatisticsService
				.getClaimVoucherStatisticsByDateAndDept(year, currMonth);
		Double count = 0.0;
		for(ClaimVoucherStatistics cv : statisticsDetailOfCompMonth){
			count += cv.getTotalCount();
		}
		DecimalFormat dFormat = new DecimalFormat("0.00");
		totalCount = dFormat.format(count);
		return "detail";
	}
	
	public String getDetailExcel() {
		statisticsDetailOfCompMonth = claimVoucherStatisticsService
				.getClaimVoucherStatisticsByDateAndDept(year, currMonth);
		List<String[]> list = new ArrayList<String[]>();
		int i = 0;
		for (ClaimVoucherStatistics cvs : statisticsDetailOfCompMonth) {
			i++;
			String index = new Integer(i).toString();
			String deptNameCell = cvs.getDepartment().getName();
			String totalCell = cvs.getTotalCount().toString();
			String yearCell = new Integer(year).toString();
			String monthCell = new Integer(currMonth).toString();
			
			list.add(new String[] { index, deptNameCell, totalCell, yearCell, monthCell});
		}
		String fileName = year + "年" + currMonth + "月" + "公司月度报销统计饼图";
		try {
			ExportExcelUtil.createExcel(getResponse(), list, fileName, "monthly", "comp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "detailExcel";
	}
	
	public String getDetailChart() {
		statisticsDetailOfCompMonth = claimVoucherStatisticsService
				.getClaimVoucherStatisticsByDateAndDept(year, currMonth);
		DefaultPieDataset dataset = new DefaultPieDataset();
		for (ClaimVoucherStatistics cvs : statisticsDetailOfCompMonth) {
			dataset.setValue(cvs.getDepartment().getName(), cvs.getTotalCount());
		}
		String title = year + "年公司月度报销统计";
		chart = new JFreeChatUtil().createPieChar3D(dataset, title);
		return "detailChart";
	}
	
	public ClaimVoucherStatisticsService getClaimVoucherStatisticsService() {
		return claimVoucherStatisticsService;
	}
	public void setClaimVoucherStatisticsService(ClaimVoucherStatisticsService claimVoucherStatisticsService) {
		this.claimVoucherStatisticsService = claimVoucherStatisticsService;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getStartMonth() {
		return startMonth;
	}
	public void setStartMonth(int startMonth) {
		this.startMonth = startMonth;
	}
	public int getEndMonth() {
		return endMonth;
	}
	public void setEndMonth(int endMonth) {
		this.endMonth = endMonth;
	}
	public int getCurrMonth() {
		return currMonth;
	}
	public void setCurrMonth(int currMonth) {
		this.currMonth = currMonth;
	}
	public String getTotalCount() {
		return totalCount;
	}
	public void setTotalCoount(String totalCount) {
		this.totalCount = totalCount;
	}
	public JFreeChart getChart() {
		return chart;
	}
	public void setChart(JFreeChart chart) {
		this.chart = chart;
	}
	public List<ClaimVoucherStatistics> getStatisticsListOfCompMonth() {
		return statisticsListOfCompMonth;
	}
	public void setStatisticsListOfCompMonth(List<ClaimVoucherStatistics> statisticsListOfComPMonth) {
		this.statisticsListOfCompMonth = statisticsListOfComPMonth;
	}
	public List<ClaimVoucherStatistics> getStatisticsDetailOfCompMonth() {
		return statisticsDetailOfCompMonth;
	}
	public void setStatisticsDetailOfCompMonth(List<ClaimVoucherStatistics> statisticsDetailOfComPMonth) {
		this.statisticsDetailOfCompMonth = statisticsDetailOfComPMonth;
	}

}
