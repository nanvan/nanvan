﻿# Host: 127.0.0.1  (Version: 5.5.28)
# Date: 2018-12-11 20:02:16
# Generator: MySQL-Front 5.3  (Build 4.214)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "sys_department"
#

DROP TABLE IF EXISTS `sys_department`;
CREATE TABLE `sys_department` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(45) NOT NULL COMMENT '部门名称',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

#
# Data for table "sys_department"
#

INSERT INTO `sys_department` VALUES (1,'人事部'),(2,'平台研发部'),(3,'产品设计部'),(4,'财务部'),(5,'总裁办公室');

#
# Structure for table "biz_claim_vouyear_statistics"
#

DROP TABLE IF EXISTS `biz_claim_vouyear_statistics`;
CREATE TABLE `biz_claim_vouyear_statistics` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TOTALCOUNT` double NOT NULL COMMENT '总金额',
  `YEAR` int(11) NOT NULL COMMENT '年份',
  `MODIFYTIME` datetime NOT NULL COMMENT '修改时间',
  `DEPARTMENT_ID` int(11) NOT NULL COMMENT '部门',
  PRIMARY KEY (`ID`),
  KEY `FK_lmynuuf253l9ibt2tjp3gb0yb` (`DEPARTMENT_ID`),
  CONSTRAINT `FK_lmynuuf253l9ibt2tjp3gb0yb` FOREIGN KEY (`DEPARTMENT_ID`) REFERENCES `sys_department` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

#
# Data for table "biz_claim_vouyear_statistics"
#

INSERT INTO `biz_claim_vouyear_statistics` VALUES (10,17898,2017,'2018-10-19 11:15:31',1);

#
# Structure for table "biz_claim_voucher_statistics"
#

DROP TABLE IF EXISTS `biz_claim_voucher_statistics`;
CREATE TABLE `biz_claim_voucher_statistics` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `TOTALCOUNT` double NOT NULL COMMENT '总金额',
  `YEAR` int(11) NOT NULL COMMENT '年份',
  `MONTH` int(11) NOT NULL COMMENT '月份',
  `DEPARTMENT_ID` int(11) NOT NULL COMMENT '部门',
  `MODIFYTIME` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`ID`),
  KEY `FK_b92es1bteosmp13cm6nrbhu7a` (`DEPARTMENT_ID`),
  CONSTRAINT `FK_b92es1bteosmp13cm6nrbhu7a` FOREIGN KEY (`DEPARTMENT_ID`) REFERENCES `sys_department` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

#
# Data for table "biz_claim_voucher_statistics"
#

INSERT INTO `biz_claim_voucher_statistics` VALUES (3,7877,2018,9,1,'2018-10-19 11:15:31');

#
# Structure for table "sys_position"
#

DROP TABLE IF EXISTS `sys_position`;
CREATE TABLE `sys_position` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAMECN` varchar(45) NOT NULL COMMENT '职务名称(中文)',
  `NAMEEN` varchar(45) NOT NULL COMMENT '职务名称(英文)',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

#
# Data for table "sys_position"
#

INSERT INTO `sys_position` VALUES (1,'员工','staff'),(2,'部门经理','manager'),(3,'总经理','generalmanager'),(4,'财务','cashier');

#
# Structure for table "sys_employee"
#

DROP TABLE IF EXISTS `sys_employee`;
CREATE TABLE `sys_employee` (
  `SN` varchar(20) NOT NULL,
  `PASSWORD` varchar(45) NOT NULL COMMENT '密码',
  `DEPARTMENT_ID` int(11) NOT NULL COMMENT '部门',
  `POSITION_ID` int(11) NOT NULL COMMENT '职务编号',
  `NAME` varchar(45) NOT NULL COMMENT '姓名',
  `STATUS` varchar(20) NOT NULL COMMENT '状态',
  PRIMARY KEY (`SN`),
  KEY `FK_mqoevyq0uyoc7u508yklrqapf` (`DEPARTMENT_ID`),
  KEY `FK_4bdxt3gbw3r1630nbtu1uk2xg` (`POSITION_ID`),
  CONSTRAINT `FK_4bdxt3gbw3r1630nbtu1uk2xg` FOREIGN KEY (`POSITION_ID`) REFERENCES `sys_position` (`ID`),
  CONSTRAINT `FK_mqoevyq0uyoc7u508yklrqapf` FOREIGN KEY (`DEPARTMENT_ID`) REFERENCES `sys_department` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# Data for table "sys_employee"
#

INSERT INTO `sys_employee` VALUES ('001','123',1,1,'张平','在职'),('002','123',1,2,'叶宁','在职'),('003','123',1,3,'李伟','在职'),('004','123',1,4,'王小明','离职'),('005','123',1,1,'林风','在职'),('006','123',2,2,'张大明','在职'),('007','123',2,1,'李大伟','在职'),('008','123',2,1,'张总','在职'),('009','123',3,1,'李峰','在职'),('010','123',3,2,'李大伟1','在职'),('011','123',3,1,'李小伟1','在职'),('012','123',3,1,'李大伟2','在职'),('013','123',4,1,'李大伟3','在职'),('014','123',4,2,'李大伟4','在职'),('015','123',4,1,'李大伟5','在职'),('016','123',4,1,'李大伟6','在职');

#
# Structure for table "biz_claim_voucher"
#

DROP TABLE IF EXISTS `biz_claim_voucher`;
CREATE TABLE `biz_claim_voucher` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CREATOR_SN` varchar(20) NOT NULL COMMENT '填报人',
  `NEXTDEAL_SN` varchar(20) DEFAULT NULL COMMENT '待处理人',
  `CREATETIME` datetime NOT NULL COMMENT '填写时间',
  `EVENT` varchar(255) NOT NULL COMMENT '事由',
  `TOTALACCOUNT` double NOT NULL COMMENT '总金额',
  `STATUS` varchar(20) NOT NULL COMMENT '状态',
  `MODIFYTIME` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`ID`),
  KEY `FK_gx6dhgilbeb8mwpeawfloopvk` (`CREATOR_SN`),
  KEY `FK_7padrxhyhhg14fpgy4dl1yter` (`NEXTDEAL_SN`),
  CONSTRAINT `FK_7padrxhyhhg14fpgy4dl1yter` FOREIGN KEY (`NEXTDEAL_SN`) REFERENCES `sys_employee` (`SN`),
  CONSTRAINT `FK_gx6dhgilbeb8mwpeawfloopvk` FOREIGN KEY (`CREATOR_SN`) REFERENCES `sys_employee` (`SN`)
) ENGINE=InnoDB AUTO_INCREMENT=1039 DEFAULT CHARSET=utf8;

#
# Data for table "biz_claim_voucher"
#

INSERT INTO `biz_claim_voucher` VALUES (1001,'001',NULL,'2018-10-12 00:00:00','adc',1000,'付款','2018-10-17 09:05:12'),(1002,'001','004','2018-10-12 00:00:00','adc',1000,'已审批','2018-10-12 00:00:00'),(1003,'001','004','2018-10-12 00:00:00','adc',1000,'已审批','2018-10-12 00:00:00'),(1004,'001','004','2018-10-12 00:00:00','adc',1000,'已审批','2018-10-12 00:00:00'),(1005,'001','004','2018-10-12 00:00:00','adc',1000,'已审批','2018-10-12 00:00:00'),(1006,'001','004','2018-10-12 00:00:00','adc',1000,'已审批','2018-10-12 00:00:00'),(1007,'001','004','2018-10-12 00:00:00','adc',1000,'已审批','2018-10-12 00:00:00'),(1016,'001',NULL,'2018-10-15 15:41:35','111',34463,'待审批','2018-10-17 09:00:43'),(1018,'001',NULL,'2018-10-16 15:34:30','31312',3123,'待审批','2018-10-16 16:35:23'),(1019,'001',NULL,'2018-10-17 09:03:50','666',7777,'待审批','2018-10-17 09:04:36'),(1020,'001',NULL,'2018-10-17 09:08:18','411251',14443,'付款','2018-10-17 09:10:03'),(1021,'001','002','2018-10-17 09:57:14','addaaa',1131312,'已提交',NULL),(1022,'001',NULL,'2018-10-17 10:03:20','ggsgg',653656,'已终止','2018-10-17 10:03:41'),(1023,'001','004','2018-10-17 10:04:40','asfsfsas',44444,'待审批','2018-10-17 10:17:38'),(1024,'001',NULL,'2018-10-17 10:22:07','fsasfs',6666,'付款','2018-10-17 10:23:03'),(1025,'001','002','2018-10-17 10:25:48','ffafsd',545454,'已提交',NULL),(1026,'001','002','2018-10-17 10:35:49','9',99999,'已提交',NULL),(1028,'001','002','2018-10-17 10:48:31','dd',4343424,'已提交',NULL),(1029,'001','002','2018-10-17 11:14:13','1',250250250,'已提交',NULL),(1030,'001','002','2018-10-17 11:14:39','1',250250,'已提交','2018-10-17 11:14:46'),(1031,'001',NULL,'2018-10-17 11:14:57','1',250,'已付款','2018-10-17 11:16:21'),(1032,'001',NULL,'2018-10-19 10:15:44','777',8888,'已付款','2017-10-19 10:19:39'),(1033,'001',NULL,'2018-10-19 10:58:18','还花呗',3233,'已终止','2018-10-19 11:00:50'),(1036,'001',NULL,'2018-10-19 11:04:59','真好',3233,'已付款','2017-10-19 11:06:41'),(1037,'005',NULL,'2018-10-19 11:08:51','大马哈',5777,'已付款','2017-10-19 11:10:38'),(1038,'001',NULL,'2018-10-19 11:12:54','',7877,'已付款','2018-09-19 11:13:44');

#
# Structure for table "biz_check_result"
#

DROP TABLE IF EXISTS `biz_check_result`;
CREATE TABLE `biz_check_result` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CLAIMVOUCHER_ID` bigint(20) NOT NULL COMMENT '报销单编号',
  `CHECKTIME` datetime NOT NULL COMMENT '审核时间',
  `RESULT` varchar(20) NOT NULL COMMENT '审核结果',
  `COMMENT` varchar(255) DEFAULT NULL COMMENT '审核意见',
  `CHECKER_SN` varchar(20) NOT NULL COMMENT '审核人',
  PRIMARY KEY (`ID`),
  KEY `FK_lhukn8obh2er20dtq5mptt4n8` (`CLAIMVOUCHER_ID`),
  KEY `FK_2o3o3gr9k3oxnargpmk88krbb` (`CHECKER_SN`),
  CONSTRAINT `FK_2o3o3gr9k3oxnargpmk88krbb` FOREIGN KEY (`CHECKER_SN`) REFERENCES `sys_employee` (`SN`),
  CONSTRAINT `FK_lhukn8obh2er20dtq5mptt4n8` FOREIGN KEY (`CLAIMVOUCHER_ID`) REFERENCES `biz_claim_voucher` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

#
# Data for table "biz_check_result"
#

INSERT INTO `biz_check_result` VALUES (1,1018,'2018-10-16 16:35:23','通过','asgaefr','002'),(2,1016,'2018-10-17 09:00:43','通过','','002'),(3,1019,'2018-10-17 09:04:09','通过','dadadadadadaaaa','002'),(4,1019,'2018-10-17 09:04:36','通过','mjsnfjasfsafas','003'),(5,1001,'2018-10-17 09:05:12','通过','','004'),(6,1020,'2018-10-17 09:08:57','通过','grgsgdfhajreereew','002'),(7,1020,'2018-10-17 09:09:43','通过','gfgsgsgsfaf','003'),(8,1020,'2018-10-17 09:10:03','通过','gsgsddggd','004'),(9,1022,'2018-10-17 10:03:41','拒绝','afsf','002'),(10,1023,'2018-10-17 10:05:13','通过','rgsgssa','002'),(11,1023,'2018-10-17 10:17:38','通过','fsfsafd','003'),(12,1024,'2018-10-17 10:22:21','通过','fsagsg','002'),(13,1024,'2018-10-17 10:22:35','通过','hhhh','003'),(14,1024,'2018-10-17 10:23:03','通过','jjjj','004'),(15,1031,'2018-10-17 11:15:16','通过','1','002'),(16,1031,'2018-10-17 11:16:21','通过','1','004'),(17,1032,'2018-10-19 10:16:32','通过','部门经理说真好','002'),(18,1032,'2018-10-19 10:18:18','通过','总经理说真好','003'),(19,1032,'2018-10-19 10:19:39','通过','财务说真好','004'),(20,1033,'2018-10-19 11:00:50','拒绝','','002'),(21,1036,'2018-10-19 11:05:39','通过','大马猴','002'),(22,1036,'2018-10-19 11:06:41','通过','加油！真好！','004'),(23,1037,'2018-10-19 11:09:51','通过','大马猴','002'),(24,1037,'2018-10-19 11:10:14','通过','真好','003'),(25,1037,'2018-10-19 11:10:38','通过','加油','004'),(26,1038,'2018-10-19 11:13:08','通过','','002'),(27,1038,'2018-10-19 11:13:28','通过','','003'),(28,1038,'2018-10-19 11:13:44','通过','1','004');

#
# Structure for table "biz_claim_voucher_detail"
#

DROP TABLE IF EXISTS `biz_claim_voucher_detail`;
CREATE TABLE `biz_claim_voucher_detail` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CLAIMVOUCHER_ID` bigint(20) NOT NULL COMMENT '报销单编号',
  `ITEM` varchar(20) NOT NULL COMMENT '项目',
  `ACCOUNT` double NOT NULL COMMENT '金额',
  `DESCRIPTION` varchar(200) NOT NULL COMMENT '费用说明',
  PRIMARY KEY (`ID`),
  KEY `FK_6yjdevoksriv3r36sq91cywyi` (`CLAIMVOUCHER_ID`),
  CONSTRAINT `FK_6yjdevoksriv3r36sq91cywyi` FOREIGN KEY (`CLAIMVOUCHER_ID`) REFERENCES `biz_claim_voucher` (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

#
# Data for table "biz_claim_voucher_detail"
#

INSERT INTO `biz_claim_voucher_detail` VALUES (5,1016,'市内交通费',11,'11'),(6,1016,'城际交通费',31321,'313'),(8,1018,'通讯费',3123,'1312'),(9,1019,'城际交通费',3333,'3333'),(11,1020,'城际交通费',7777,'7'),(12,1020,'城际交通费',6666,'6'),(13,1021,'城际交通费',1131312,'3131231'),(14,1022,'城际交通费',653656,'56634'),(16,1024,'城际交通费',6666,'6666'),(17,1025,'城际交通费',545454,''),(20,1028,'城际交通费',4343424,''),(21,1029,'城际交通费',250250250,''),(23,1030,'城际交通费',250250,''),(24,1031,'城际交通费',250,''),(27,1032,'城际交通费',4444,'4444'),(28,1032,'城际交通费',4444,'4444'),(29,1033,'城际交通费',1233,'1233'),(30,1033,'城际交通费',2000,'/'),(39,1036,'城际交通费',1233,'1233'),(40,1036,'城际交通费',2000,''),(41,1037,'城际交通费',2333,''),(42,1037,'城际交通费',3444,'3444'),(43,1038,'城际交通费',7877,'');

#
# Structure for table "biz_leave"
#

DROP TABLE IF EXISTS `biz_leave`;
CREATE TABLE `biz_leave` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `STARTTIME` datetime NOT NULL COMMENT '开始时间',
  `ENDTIME` datetime NOT NULL COMMENT '结束时间',
  `LEAVEDAY` double NOT NULL COMMENT '请假天数',
  `REASON` longtext NOT NULL COMMENT '请假原因',
  `STATUS` varchar(20) DEFAULT NULL COMMENT '状态',
  `LEAVETYPE` varchar(50) DEFAULT NULL COMMENT '请假类型',
  `APPROVEOPINION` varchar(100) DEFAULT NULL COMMENT '批准意見',
  `CREATETIME` datetime DEFAULT NULL COMMENT '创建时间',
  `MODIFYTIME` datetime DEFAULT NULL COMMENT '修改时间',
  `CREATOR_SN` varchar(20) NOT NULL COMMENT '填报人',
  `NEXTDEAL_SN` varchar(20) DEFAULT NULL COMMENT '待处理人',
  PRIMARY KEY (`ID`),
  KEY `FK_6w09jmhibmd23vmyw3ivdv8s6` (`CREATOR_SN`),
  KEY `FK_jxb22ale0oxwv3sg1kbn8028m` (`NEXTDEAL_SN`),
  CONSTRAINT `FK_6w09jmhibmd23vmyw3ivdv8s6` FOREIGN KEY (`CREATOR_SN`) REFERENCES `sys_employee` (`SN`),
  CONSTRAINT `FK_jxb22ale0oxwv3sg1kbn8028m` FOREIGN KEY (`NEXTDEAL_SN`) REFERENCES `sys_employee` (`SN`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

#
# Data for table "biz_leave"
#

INSERT INTO `biz_leave` VALUES (1,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(2,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(3,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(4,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(5,'2018-10-10 00:00:00','2018-11-10 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-10 00:00:00','2018-10-10 00:00:00','001','002'),(6,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(7,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(8,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(9,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(10,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(11,'2018-10-11 00:00:00','2018-11-11 00:00:00',3,'感冒\r\n','已审批','病假','真好','2018-10-11 00:00:00','2018-10-11 00:00:00','001','002'),(12,'2018-10-09 00:00:00','2018-10-09 00:00:00',6,'zhenhao','已打回 ','婚假','','2018-10-11 23:20:56','2018-10-12 10:11:34','001','002'),(14,'2018-10-12 00:00:00','2018-10-12 00:00:00',365,'真好','已审批 ','婚假','么么哒','2018-10-12 10:14:21','2018-10-12 10:15:37','001','002'),(15,'2018-10-13 00:00:00','2018-10-13 00:00:00',333,'我是陆超','已打回 ','事假','卢本伟牛逼','2018-10-12 10:30:18','2018-10-12 10:31:34','001','002'),(16,'2018-10-13 00:00:00','2018-10-13 00:00:00',555,'fafdasfsf','已打回 ','婚假','回复随后啥谁说的','2018-10-12 11:40:55','2018-10-12 11:41:16','001','002'),(17,'2018-10-15 00:00:00','2018-10-15 00:00:00',55,'dada','已审批 ','事假','dad','2018-10-12 13:25:24','2018-10-12 13:25:42','001','002'),(18,'2018-10-19 00:00:00','2018-10-19 00:00:00',777,'真好','已审批 ','产假','部门经理说真好','2018-10-19 10:15:23','2018-10-19 10:16:50','001','002'),(19,'2018-10-20 00:00:00','2018-10-20 00:00:00',365,'股东会的痕迹','待审批','年假',NULL,'2018-10-19 10:20:46',NULL,'001','002');

#
# Structure for table "walkthrough"
#

DROP TABLE IF EXISTS `walkthrough`;
CREATE TABLE `walkthrough` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `lTitle` varchar(255) DEFAULT NULL COMMENT '英雄称号',
  `ability0` varchar(255) DEFAULT NULL COMMENT '被动技能图片',
  `description0` varchar(255) DEFAULT NULL COMMENT '被动描述',
  `ability1` varchar(255) DEFAULT NULL COMMENT '主动技能Q图片',
  `description1` varchar(255) DEFAULT NULL COMMENT '技能Q描述',
  `ability2` varchar(255) DEFAULT NULL COMMENT '主动技能W图片',
  `description2` varchar(255) DEFAULT NULL COMMENT '技能W描述',
  `ability3` varchar(255) DEFAULT NULL COMMENT '主动技能E图片',
  `description3` varchar(255) DEFAULT NULL COMMENT '技能E描述',
  `ability4` varchar(255) DEFAULT NULL COMMENT '主动技能R图片',
  `description4` varchar(255) DEFAULT NULL COMMENT '技能R描述',
  `equipment1` varchar(255) DEFAULT NULL COMMENT '装备1',
  `equipment2` varchar(255) DEFAULT NULL COMMENT '装备2',
  `equipment3` varchar(255) DEFAULT NULL COMMENT '装备3',
  `equipment4` varchar(255) DEFAULT NULL COMMENT '装备4',
  `equipment5` varchar(255) DEFAULT NULL COMMENT '装备5',
  `equipment6` varchar(255) DEFAULT NULL COMMENT '装备6',
  `tips` varchar(255) DEFAULT NULL COMMENT '使用技巧',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='嘤雄攻略';

#
# Data for table "walkthrough"
#

INSERT INTO `walkthrough` VALUES (1,'圣枪游侠','Lucian0.png','圣光银弹','LucianQ.png','透体圣光','LucianW.png','热诚烈弹','LucianE.png','冷酷追击','LucianR.png','圣枪洗礼',NULL,NULL,'heiqie.png',NULL,NULL,NULL,NULL);
