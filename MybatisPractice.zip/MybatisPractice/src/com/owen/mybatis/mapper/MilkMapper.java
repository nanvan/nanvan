package com.owen.mybatis.mapper;

import java.util.List;

import com.owen.mybatis.pojo.Milk;

public interface MilkMapper {
	//mapper动态代理开发，用接口代替传统dao开发的接口+实现类
	//遵循四个原则
	//1.接口的方法名   == Milk.xml 中的 id 名
	//2.返回值(输出参数)类型  与  Milk.xml 中的resultType一致
	//3.方法的(输)入参类型  与  Mapper.xml 中的parameterType一致
	//4.命名空间绑定此接口(类路径)
	public Milk findMilkById(Integer id);
	
	public List<Milk> findMilkByMname(String mname);

}
