package com.owen.mybatis.dao;

public interface MilkDao {

}
