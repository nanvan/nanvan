package com.owen.mybatis.dao;

import com.owen.mybatis.pojo.Milk;

public interface MilkDao {
	//通过牛奶ID查询一条牛奶信息
		public Milk selectMilkById(Integer id);

}
