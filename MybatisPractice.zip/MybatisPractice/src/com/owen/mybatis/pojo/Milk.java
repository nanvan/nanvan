package com.owen.mybatis.pojo;

import java.io.Serializable;

public class Milk implements Serializable{//实现虚拟化接口
		private static final long serialVersionUID = 1L;
		private int id;				//牛奶编号
		private String mname;		//牛奶名称
		private int stock;			//库存
		private double price;		//单价
		
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getMname() {
			return mname;
		}
		public void setMname(String mname) {
			this.mname = mname;
		}
		public int getStock() {
			return stock;
		}
		public void setStock(int stock) {
			this.stock = stock;
		}
		public double getPrice() {
			return price;
		}
		public void setPrice(double price) {
			this.price = price;
		}
		
		@Override
		public String toString() {
			return "Milk [id=" + id + ", mname=" + mname + ", stock=" + stock
					+ ", price=" + price + "]";
		}
		
		
		
}
