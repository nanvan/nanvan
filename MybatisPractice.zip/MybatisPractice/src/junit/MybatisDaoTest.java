package junit;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Before;
import org.junit.Test;

import com.owen.mybatis.dao.MilkDao;
import com.owen.mybatis.dao.MilkDaoImpl;
import com.owen.mybatis.pojo.Milk;

public class MybatisDaoTest {

	private SqlSessionFactory sqlSessionFactory;

	@Before
	public void before() throws Exception{
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建sqlSessionFactory
		sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);

	}

	@Test
	public void testDao() throws Exception{

		MilkDao milkDao = new MilkDaoImpl(sqlSessionFactory);
		Milk milk = milkDao.selectMilkById(1001);
		System.out.println(milk);
	}

}
