package junit;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.owen.mybatis.pojo.Milk;

public class mybatisTest {

	//通过ID查询一个牛奶
	@Test
	public void testFindMilkById() throws Exception {
		//加载核心配置文件，快速创建局部变量快捷键Ctrl+2+L,Alt+Shift+L
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建sqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建sqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();

		//执行sql语句
		Milk milk = sqlSession.selectOne("mm.findMilkById", 1005);

		System.out.println(milk);
	}

	//根据牛奶名称模糊查询牛奶列表
	@Test
	public void testFindMilkByMname() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建sqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建sqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();

		//执行sql语句
		List<Milk> milks = sqlSession.selectList("mm.findMilkByMname", "金");
		for(Milk milk2 : milks){
			System.out.println(milk2);
		}
	}

	//新增牛奶信息
	@Test
	public void testInsertMilk() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建sqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建sqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();

		//执行sql语句
		Milk milk = new Milk();
		milk.setMname("咕叽咕叽");
		milk.setPrice(7.65);
		milk.setStock(250);
		int ii = sqlSession.insert("mm.insertMilk", milk);
		sqlSession.commit();

		System.out.println(milk.getId());
	}

	//更新一个牛奶的信息
	@Test
	public void testUpdateMilkById() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建sqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建sqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();

		//执行sql语句
		Milk milk = new Milk();
		milk.setId(1011);
		milk.setMname("咕叽咕叽0.0");
		milk.setPrice(6.56);
		milk.setStock(520);
		int ii = sqlSession.update("mm.updateMilkById",milk);
		sqlSession.commit();

	}

	//删除一条牛奶信息
	@Test
	public void testDeleteMilkById() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建sqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建sqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();

		//执行sql语句
		int ii = sqlSession.delete("mm.deleteMilkById", 1011);
		sqlSession.commit();

	}

}




