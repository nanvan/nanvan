package junit;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.owen.mybatis.mapper.MOrderMapper;
import com.owen.mybatis.mapper.MilkMapper;
import com.owen.mybatis.pojo.MOrder;
import com.owen.mybatis.pojo.Milk;

public class MybatisMapperTest2 {
	
	//一对一
	@Test
	public void testMOrderList() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建sqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建sqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		//SqlSession帮我生成一个实现类  （给接口）
		MOrderMapper morderMapper = sqlSession.getMapper(MOrderMapper.class);
		List<MOrder> selectMOrder = morderMapper.selectMOrder();
		
		for(MOrder morder : selectMOrder){
			System.out.println(morder);
		}
	}
	
	//一对多
		@Test
		public void testMilkList() throws Exception {
			//加载核心配置文件
			String resource = "sqlMapConfig.xml";
			InputStream in = Resources.getResourceAsStream(resource);
			//创建sqlSessionFactory
			SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
			//创建sqlSession
			SqlSession sqlSession = sqlSessionFactory.openSession();
			
			//SqlSession帮我生成一个实现类  （给接口）
			MOrderMapper morderMapper = sqlSession.getMapper(MOrderMapper.class);
			List<Milk> milks = morderMapper.selectMilkList();
			
			for(Milk milk : milks){
				System.out.println(milk);
			}
		}
	
}
