package junit;

import java.io.InputStream;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import com.owen.mybatis.mapper.MOrderMapper;
import com.owen.mybatis.mapper.MilkMapper;
import com.owen.mybatis.pojo.MOrder;
import com.owen.mybatis.pojo.Milk;
import com.owen.mybatis.pojo.QueryVo;

public class MybatisMapperTest {

	@Test
	public void testMapper() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建sqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建sqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		//给SqlSession 接口，它便为你生成  实现类
		MilkMapper milkMapper = sqlSession.getMapper(MilkMapper.class);
		Milk milk = milkMapper.findMilkById(1005);
		System.out.println(milk);
	}
	@Test
	public void testMapperQueryVo() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建SqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建SqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		//SqlSession帮我生成一个实现类  （给接口）
		MilkMapper userMapper = sqlSession.getMapper(MilkMapper.class);
		QueryVo vo = new QueryVo();
		Milk milk = new Milk();
		milk.setMname("金");
		vo.setMilk(milk);
		
		List<Milk> mm = userMapper.findMilkByQueryVo(vo);
		for (Milk m : mm) {
			System.out.println(m);
			
		}
	}
	@Test
	public void testMapperQueryVoCount() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建SqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建SqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		//SqlSEssion帮我生成一个实现类  （给接口）
		MilkMapper milkMapper = sqlSession.getMapper(MilkMapper.class);
		
		Integer ii = milkMapper.countMilk();
		System.out.println(ii);
	}
//	查询订单表morder的所有数据
	@Test
	public void testMOrderList() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建SqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建SqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		MOrderMapper mapper = sqlSession.getMapper(MOrderMapper.class);
		
		List<MOrder> morderList = mapper.selectMOrderList();
		for (MOrder morder : morderList) {
			System.out.println(morder);
		}
	}
//	根据单价和名字查询牛奶
	@Test
	public void testfindUserBySexAndUsername() throws Exception {
		//加载核心配置文件
		String resource = "sqlMapConfig.xml";
		InputStream in = Resources.getResourceAsStream(resource);
		//创建SqlSessionFactory
		SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(in);
		//创建SqlSession
		SqlSession sqlSession = sqlSessionFactory.openSession();
		
		MilkMapper milkMapper = sqlSession.getMapper(MilkMapper.class);
		Milk milk = new Milk();
		milk.setPrice(6);
		milk.setMname("特仑苏");
		List<Milk> milks = milkMapper.selectMilkByPriceAndMname(milk);
		for (Milk milk2 : milks) {
			System.out.println(milk2);
		}
	}

}
