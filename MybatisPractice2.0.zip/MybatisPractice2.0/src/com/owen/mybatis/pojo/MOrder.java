package com.owen.mybatis.pojo;

import java.io.Serializable;
import java.util.Date;

public class MOrder  implements Serializable{

	private static final long serialVersionUID = 1L;

	private Integer id;

    private Integer milkId;

    private Date createtime;
    
    private Integer number;
    
    //附加对象，一对一
    private Milk milk;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getMilkId() {
		return milkId;
	}

	public void setMilkId(Integer milkId) {
		this.milkId = milkId;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public Milk getMilk() {
		return milk;
	}

	public void setMilk(Milk milk) {
		this.milk = milk;
	}
	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	@Override
	public String toString() {
		return "MOrder [id=" + id + ", milkId=" + milkId + ", createtime="
				+ createtime + ", milk=" + milk + "]";
	}

	
    
    
}