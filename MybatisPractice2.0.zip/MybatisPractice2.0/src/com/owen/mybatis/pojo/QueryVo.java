package com.owen.mybatis.pojo;
import java.io.Serializable;
import java.util.List;

public class QueryVo implements Serializable {


	private static final long serialVersionUID = 1L;

	private Milk milk;
	
	List<Integer> idsList;
	
	Integer[] ids;

	public List<Integer> getIdsList() {
		return idsList;
	}
	public void setIdsList(List<Integer> idsList) {
		this.idsList = idsList;
	}
	public Integer[] getIds() {
		return ids;
	}
	public void setIds(Integer[] ids) {
		this.ids = ids;
	}
	public Milk getMilk() {
		return milk;
	}
	public void setMilk(Milk milk) {
		this.milk = milk;
	}
	
	

}



