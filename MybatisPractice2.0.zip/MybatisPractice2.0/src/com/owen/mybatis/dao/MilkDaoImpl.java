package com.owen.mybatis.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import com.owen.mybatis.pojo.Milk;

public class MilkDaoImpl implements MilkDao {
	//手动注入
	private SqlSessionFactory sqlSessionFactory;
	//创建有参构造函数
	public MilkDaoImpl(SqlSessionFactory sqlSessionFactory) {
		super();
		this.sqlSessionFactory = sqlSessionFactory;
	}
	
	//通过牛奶ID查询一条牛奶信息
	public Milk selectMilkById(Integer id){
		SqlSession sqlSession = sqlSessionFactory.openSession();
		return sqlSession.selectOne("mm.findMilkById", id);	
	}
}
