package com.owen.mybatis.mapper;

import java.util.List;

import com.owen.mybatis.pojo.MOrder;
import com.owen.mybatis.pojo.Milk;

public interface MOrderMapper {
	
	
	//查询订单表morder的所有数据
	public List<MOrder> selectMOrderList();
	
	//一对一关联 查询  以订单为中心 关联牛奶
	public List<MOrder> selectMOrder();
	
	//一对多关联
	public List<Milk> selectMilkList();
	
}
